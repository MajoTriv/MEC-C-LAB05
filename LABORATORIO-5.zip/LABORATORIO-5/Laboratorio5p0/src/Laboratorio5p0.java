import java.awt.Color;
import java.awt.Font;
import javax.swing.*;

public class Laboratorio5p0 extends JFrame {
    
    private JLabel titulo, labelAnio, labelSexo, labelBarrio, labelComuna;
    private JComboBox<String> comboAnio, comboSexo;
    private JTextField txtBarrio, txtComuna;
    private JButton botonFiltrar;

    public Laboratorio5p0() {
        // Configuración de la ventana
        setTitle("Laboratorio 5 ");
        setSize(500, 300);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        // Creación de componentes
        titulo = new JLabel("Filtro");
        titulo.setFont(new Font("Arial", Font.BOLD, 20));
        titulo.setBounds(50, 20, 400, 30);
        
        labelAnio = new JLabel("Año:");
        labelAnio.setBounds(50, 70, 100, 30);
        
        comboAnio = new JComboBox<String>();
        for (int i = 2015; i <= 2023; i++) {
            comboAnio.addItem(String.valueOf(i));
        }
        comboAnio.setBounds(150, 70, 100, 30);
        
        labelSexo = new JLabel("Sexo:");
        labelSexo.setBounds(50, 110, 100, 30);
        
        comboSexo = new JComboBox<String>();
        comboSexo.addItem("Masculino");
        comboSexo.addItem("Femenino");
        comboSexo.setBounds(150, 110, 100, 30);
        
        labelBarrio = new JLabel("Departamento:");
        labelBarrio.setBounds(50, 150, 100, 30);
        
        txtBarrio = new JTextField();
        txtBarrio.setBounds(150, 150, 200, 30);
        
        labelComuna = new JLabel("Municipio:");
        labelComuna.setBounds(50, 190, 100, 30);
        
        txtComuna = new JTextField();
        txtComuna.setBounds(150, 190, 200, 30);
        
        botonFiltrar = new JButton("Filtrar");
        botonFiltrar.setBounds(200, 240, 100, 30);
        botonFiltrar.setBackground(new Color(128, 0, 128));
        botonFiltrar.setForeground(Color.WHITE);
        
        // Agregamos componentes a la ventana
        add(titulo);
        add(labelAnio);
        add(comboAnio);
        add(labelSexo);
        add(comboSexo);
        add(labelBarrio);
        add(txtBarrio);
        add(labelComuna);
        add(txtComuna);
        add(botonFiltrar);
        
        setLayout(null);
        setVisible(true);
    }

    public static void main(String[] args) {
        Laboratorio5p0 filtro = new Laboratorio5p0();
    }
}
/*
Obtener los tres departamentos con mayor cantidad de casos
Map<String, Integer> departamentos = new HashMap<>();
for (Dato dato : datosFiltrados) {
    String departamento = dato.getDepartamento();
    int cantidad = dato.getCantidad();
    if (departamentos.containsKey(departamento)) {
        cantidad += departamentos.get(departamento);
    }
    departamentos.put(departamento, cantidad);
}

List<Map.Entry<String, Integer>> topDepartamentos = departamentos.entrySet().stream()
    .sorted(Collections.reverseOrder(Map.Entry.comparingByValue()))
    .
*/
