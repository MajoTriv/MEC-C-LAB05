package laboratorio5p2;

import java.awt.Color;
import java.awt.Font;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import javax.swing.*;

public class Laboratorio5p2 extends JFrame {
    
    private JLabel titulo, labelAnio, labelSexo, labelBarrio, labelComuna;
    private JComboBox<String> comboAnio, comboSexo;
    private JTextField txtBarrio, txtComuna;
    private JButton botonFiltrar;
    private JTextArea resultado;
    private JScrollPane scroll;

    public Laboratorio5p2() {
        // Configuración de la ventana
        setTitle("Filtros para análisis de feminicidios");
        setSize(500, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        // Creación de componentes
        titulo = new JLabel("Filtros para análisis de feminicidios");
        titulo.setFont(new Font("Arial", Font.BOLD, 20));
        titulo.setBounds(50, 20, 400, 30);
        
        labelAnio = new JLabel("Año:");
        labelAnio.setBounds(50, 70, 100, 30);
        
        comboAnio = new JComboBox<String>();
        for (int i = 2015; i <= 2023; i++) {
            comboAnio.addItem(String.valueOf(i));
        }
        comboAnio.setBounds(150, 70, 100, 30);
        
        labelSexo = new JLabel("Sexo:");
        labelSexo.setBounds(50, 110, 100, 30);
        
        comboSexo = new JComboBox<String>();
        comboSexo.addItem("Masculino");
        comboSexo.addItem("Femenino");
        comboSexo.setBounds(150, 110, 100, 30);
        
        labelBarrio = new JLabel("Departamento:");
        labelBarrio.setBounds(50, 150, 100, 30);
        
        txtBarrio = new JTextField();
        txtBarrio.setBounds(150, 150, 200, 30);
        
        labelComuna = new JLabel("Municipio:");
        labelComuna.setBounds(50, 190, 100, 30);
        
        txtComuna = new JTextField();
        txtComuna.setBounds(150, 190, 200, 30);
        
        botonFiltrar = new JButton("Filtrar");
        botonFiltrar.setBounds(200, 240, 100, 30);
        botonFiltrar.setBackground(new Color(128, 0, 128));
        botonFiltrar.setForeground(Color.WHITE);
        
        resultado = new JTextArea();
        resultado.setEditable(false);
        resultado.setLineWrap(true);
        scroll = new JScrollPane(resultado);
        scroll.setBounds(50, 280, 400, 70);
        
        // Agregamos componentes a la ventana
        add(titulo);
        add(labelAnio);
        add(comboAnio);
        add(labelSexo);
        add(comboSexo);
        add(labelBarrio);
        add(txtBarrio);
        add(labelComuna);
        add(txtComuna);
        add(botonFiltrar);
        add(scroll);
        
        setLayout(null);
        setVisible(true);
        
        botonFiltrar.addActionListener((event) -> {
            // Obtener los datos seleccionados y escritos en los campos
            String anioSeleccionado = (String) comboAnio.getSelectedItem();
            String sexoSeleccionado = (String) comboSexo.getSelectedItem();
            String departamentoEscrito = txtBarrio.getText().trim();
            String municipioEscrito = txtComuna.getText().trim();
                    // Filtrar los feminicidios según los criterios seleccionados
        ArrayList<Feminicidio> feminicidiosFiltrados = filtrarFeminicidios(anioSeleccionado, sexoSeleccionado, departamentoEscrito, municipioEscrito);

        // Ordenar los feminicidios filtrados por fecha
        Collections.sort(feminicidiosFiltrados, Comparator.comparing(Feminicidio::getFecha));

        // Mostrar los feminicidios filtrados en el JTextArea
        resultado.setText("");
        for (Feminicidio f : feminicidiosFiltrados) {
            resultado.append(f.toString() + "\n");
        }
    });
}

public ArrayList<Feminicidio> filtrarFeminicidios(String anioSeleccionado, String sexoSeleccionado, String departamentoEscrito, String municipioEscrito) {
    // Cargar los datos del archivo CSV
    ArrayList<Feminicidio> feminicidios = new ArrayList<>();
    try {
        CSVReader csvReader = new CSVReaderBuilder(new FileReader("feminicidios.csv")).withSkipLines(1).build();
        String[] fila;
        while ((fila = csvReader.readNext()) != null) {
            if (fila[0].equals(anioSeleccionado) && fila[1].equals(sexoSeleccionado) && fila[4].equalsIgnoreCase(departamentoEscrito) && fila[5].equalsIgnoreCase(municipioEscrito)) {
                Feminicidio f = new Feminicidio(fila[0], fila[1], fila[2], fila[3], fila[4], fila[5], fila[6], fila[7], fila[8], fila[9], fila[10], fila[11], fila[12], fila[13]);
                feminicidios.add(f);
            }
        }
    } catch (FileNotFoundException e) {
        e.printStackTrace();
    } catch (IOException e) {
        e.printStackTrace();
    }

    return feminicidios;
}

public static void main(String[] args) {
    new Laboratorio5p0();
}
}
