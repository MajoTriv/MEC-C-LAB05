public class Registro {
    private String departamento;
    private String municipio;
    private int año;
    private String sexo;
    private int cantidad;

    // constructor, getters y setters
}
List<Registro> registros = new ArrayList<>();

try (Scanner scanner = new Scanner(new File("Archivoguia"))) {
    scanner.nextLine(); // saltar la primera línea que contiene los nombres de las columnas

    while (scanner.hasNextLine()) {
        String line = scanner.nextLine();
        String[] fields = line.split(",");

        Registro registro = new Registro();
        registro.setDepartamento(fields[1]);
        registro.setMunicipio(fields[2]);
        registro.setAño(Integer.parseInt(fields[3]));
        registro.setSexo(fields[4]);
        registro.setCantidad(Integer.parseInt(fields[5]));

        registros.add(registro);
    }
} catch (FileNotFoundException e) {
    e.printStackTrace();
}
private void filtrarButtonActionPerformed(ActionEvent evt) {
    String departamento = departamentoComboBox.getSelectedItem().toString();
    String municipio = municipioComboBox.getSelectedItem().toString();
    int año = (int) añoSpinner.getValue();
    String sexo = sexoComboBox.getSelectedItem().toString();

    List<Registro> registrosFiltrados = new ArrayList<>();

    for (Registro registro : registros) {
        if (registro.getDepartamento().equals(departamento) &&
            registro.getMunicipio().equals(municipio) &&
            registro.getAño() == año &&
            registro.getSexo().equals(sexo)) {
            registrosFiltrados.add(registro);
        }
    }

    // hacer algo con los registros filtrados, por ejemplo mostrarlos en una tabla
}
List<String> departamentos = new ArrayList<>();
List<String> municipios = new ArrayList<>();

for (Registro registro : registros) {
    if (!departamentos.contains(registro.getDepartamento())) {
        departamentos.add(registro.getDepartamento());
    }
    if (!municipios.contains(registro.getMunicipio())) {
        municipios.add(registro.getMunicipio());
    }
}

departamentoComboBox.setModel(new DefaultComboBoxModel(departamentos.toArray()));
municipioComboBox.setModel(new DefaultComboBoxModel(municipios.toArray()));

